"""
E-Commerce Flash Sale Platform - Instrumented Application
Includes Prometheus metrics, structured JSON logging, and error simulation endpoints.
"""

import time
import uuid
import random
import logging
import json
import os
from datetime import datetime

from flask import Flask, request, jsonify, g
from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST
import psutil

# ── Structured JSON Logger ──────────────────────────────────────────────────

class JSONFormatter(logging.Formatter):
    def format(self, record):
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "line": record.lineno,
        }
        if hasattr(record, "request_id"):
            log_entry["request_id"] = record.request_id
        if hasattr(record, "traceback"):
            log_entry["traceback"] = record.traceback
        if record.exc_info:
            log_entry["exception"] = self.formatException(record.exc_info)
        return json.dumps(log_entry)


handler = logging.StreamHandler()
handler.setFormatter(JSONFormatter())
logger = logging.getLogger("ecommerce.app")
logger.setLevel(logging.DEBUG)
logger.addHandler(handler)

# ── Flask App ────────────────────────────────────────────────────────────────

app = Flask(__name__)

# ── Prometheus Metrics ───────────────────────────────────────────────────────

REQUEST_COUNT = Counter(
    "http_requests_total",
    "Total HTTP request count",
    ["method", "endpoint", "http_status"]
)

REQUEST_LATENCY = Histogram(
    "http_request_duration_seconds",
    "HTTP request latency in seconds",
    ["method", "endpoint"],
    buckets=[0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0]
)

REQUESTS_IN_PROGRESS = Gauge(
    "http_requests_in_progress",
    "Number of HTTP requests currently in progress",
    ["method", "endpoint"]
)

CPU_USAGE = Gauge("app_cpu_usage_percent", "Application host CPU usage percent")
MEMORY_USAGE = Gauge("app_memory_usage_percent", "Application host memory usage percent")
MEMORY_BYTES = Gauge("app_memory_usage_bytes", "Application host memory usage bytes")

ORDER_COUNTER = Counter("ecommerce_orders_total", "Total orders placed", ["status"])
ACTIVE_SESSIONS = Gauge("ecommerce_active_sessions", "Active user sessions")
DB_ERRORS = Counter("ecommerce_db_errors_total", "Database connection errors")
CART_VALUE = Histogram("ecommerce_cart_value_pkr", "Cart value in PKR",
                       buckets=[500, 1000, 2500, 5000, 10000, 25000, 50000])

# ── Middleware: request ID + timing ─────────────────────────────────────────

@app.before_request
def before_request():
    g.start_time = time.time()
    g.request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
    REQUESTS_IN_PROGRESS.labels(method=request.method, endpoint=request.path).inc()


@app.after_request
def after_request(response):
    elapsed = time.time() - g.start_time
    REQUEST_LATENCY.labels(method=request.method, endpoint=request.path).observe(elapsed)
    REQUEST_COUNT.labels(
        method=request.method,
        endpoint=request.path,
        http_status=response.status_code
    ).inc()
    REQUESTS_IN_PROGRESS.labels(method=request.method, endpoint=request.path).dec()

    logger.info(
        f"{request.method} {request.path} → {response.status_code} ({elapsed*1000:.1f}ms)",
        extra={"request_id": g.request_id}
    )
    return response

# ── System metrics refresh ───────────────────────────────────────────────────

def refresh_system_metrics():
    CPU_USAGE.set(psutil.cpu_percent(interval=None))
    mem = psutil.virtual_memory()
    MEMORY_USAGE.set(mem.percent)
    MEMORY_BYTES.set(mem.used)

# ── Routes ───────────────────────────────────────────────────────────────────

@app.route("/metrics")
def metrics():
    refresh_system_metrics()
    return generate_latest(), 200, {"Content-Type": CONTENT_TYPE_LATEST}


@app.route("/health")
def health():
    return jsonify({"status": "ok", "timestamp": datetime.utcnow().isoformat()})


@app.route("/")
def index():
    return jsonify({
        "service": "EcomPK Flash Sale Platform",
        "version": "2.1.0",
        "region": "Islamabad, PK"
    })


@app.route("/products")
def products():
    # Simulate variable latency (flash sale load)
    time.sleep(random.uniform(0.01, 0.3))
    return jsonify({
        "products": [
            {"id": "PKT-001", "name": "Samsung Galaxy S24", "price_pkr": 189999},
            {"id": "PKT-002", "name": "Nike Air Max 2024",  "price_pkr": 32000},
            {"id": "PKT-003", "name": "Haier 1.5 Ton AC",   "price_pkr": 95000},
        ],
        "request_id": g.request_id
    })


@app.route("/orders", methods=["POST"])
def place_order():
    time.sleep(random.uniform(0.05, 0.5))
    cart_value = random.uniform(1000, 45000)
    CART_VALUE.observe(cart_value)

    if random.random() < 0.04:   # 4% random order failure
        ORDER_COUNTER.labels(status="failed").inc()
        return jsonify({"error": "Payment gateway timeout", "request_id": g.request_id}), 502

    ORDER_COUNTER.labels(status="success").inc()
    return jsonify({
        "order_id": f"ORD-{uuid.uuid4().hex[:8].upper()}",
        "cart_value_pkr": round(cart_value, 2),
        "status": "confirmed",
        "request_id": g.request_id
    }), 201


@app.route("/simulate/memory-leak")
def simulate_memory_leak():
    """Simulate a gradual memory leak for alerting demonstration."""
    leak = []
    for _ in range(50_000):
        leak.append(" " * 1024)  # allocate ~50 MB
    logger.warning("Memory leak simulation triggered", extra={"request_id": g.request_id})
    return jsonify({"status": "leak_simulated", "allocated_mb": 50})


@app.route("/simulate/db-error")
def simulate_db_error():
    """
    Simulate a broken database connection with full traceback.
    This endpoint is used for Task 2 audit proof.
    """
    request_id = g.request_id
    logger.error(
        "CRITICAL: Database connection pool exhausted during flash sale",
        extra={
            "request_id": request_id,
            "traceback": (
                "Traceback (most recent call last):\n"
                '  File "app.py", line 142, in place_order\n'
                '    conn = db_pool.getconn(timeout=2)\n'
                '  File "psycopg2/pool.py", line 85, in getconn\n'
                "    raise PoolError('connection pool exhausted')\n"
                "psycopg2.pool.PoolError: connection pool exhausted\n"
                "NullPointerError: Cannot read property 'user_id' of undefined"
            ),
        }
    )
    DB_ERRORS.inc()
    return jsonify({
        "error": "Database connection pool exhausted",
        "request_id": request_id,
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "trace": "psycopg2.pool.PoolError: connection pool exhausted"
    }), 500


@app.route("/simulate/null-pointer")
def simulate_null_pointer():
    """Simulate a NullPointerError / AttributeError for log analysis."""
    request_id = g.request_id
    try:
        user = None
        _ = user["cart"]   # deliberate TypeError
    except TypeError as exc:
        logger.critical(
            f"NullPointerError: attempt to access cart on NoneType user object — {exc}",
            exc_info=True,
            extra={"request_id": request_id}
        )
        return jsonify({
            "error": "Internal server error",
            "request_id": request_id,
            "timestamp": datetime.utcnow().isoformat() + "Z"
        }), 500


@app.route("/simulate/high-error-rate")
def simulate_high_error_rate():
    """Generate rapid 500 errors to trigger the error-rate alert."""
    errors = 0
    for _ in range(20):
        REQUEST_COUNT.labels(method="GET", endpoint="/orders", http_status=500).inc()
        errors += 1
    logger.error(f"High error rate simulation: injected {errors} 500 responses",
                 extra={"request_id": g.request_id})
    return jsonify({"injected_errors": errors, "request_id": g.request_id})


# ── Entrypoint ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    ACTIVE_SESSIONS.set(random.randint(120, 450))
    app.run(host="0.0.0.0", port=5000, debug=False)
