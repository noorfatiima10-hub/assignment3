const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  HeadingLevel, AlignmentType, BorderStyle, WidthType, ShadingType,
  LevelFormat, PageBreak, TabStopType, TabStopPosition
} = require('docx');
const fs = require('fs');

// ── Colors ───────────────────────────────────────────────────────────────────
const NAVY    = "1B2A4A";
const BLUE    = "2563EB";
const CYAN    = "0891B2";
const GREEN   = "16A34A";
const RED     = "DC2626";
const ORANGE  = "EA580C";
const GRAY    = "6B7280";
const LIGHTBG = "F0F4FF";
const HEADBG  = "1B2A4A";
const ROWBG   = "F8FAFF";

// ── Border helpers ───────────────────────────────────────────────────────────
const border = (color = "CCCCCC", size = 4) => ({ style: BorderStyle.SINGLE, size, color });
const allBorders = (c = "CCCCCC") => ({ top: border(c), bottom: border(c), left: border(c), right: border(c) });
const noBorders = () => ({
  top: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
  bottom: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
  left: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
  right: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
});

// ── Cell helper ──────────────────────────────────────────────────────────────
function cell(content, opts = {}) {
  const {
    width = 4680, bg = null, bold = false, color = "000000",
    size = 20, align = AlignmentType.LEFT, isHeader = false,
    borders: b = allBorders()
  } = opts;
  return new TableCell({
    width: { size: width, type: WidthType.DXA },
    borders: b,
    shading: bg ? { fill: bg, type: ShadingType.CLEAR } : undefined,
    margins: { top: 100, bottom: 100, left: 140, right: 140 },
    children: [new Paragraph({
      alignment: align,
      children: [new TextRun({
        text: content,
        bold: bold || isHeader,
        color: isHeader ? "FFFFFF" : color,
        size
      })]
    })]
  });
}

// ── Text helpers ─────────────────────────────────────────────────────────────
const h1 = (text) => new Paragraph({
  heading: HeadingLevel.HEADING_1,
  spacing: { before: 320, after: 120 },
  children: [new TextRun({ text, color: NAVY, size: 40, bold: true })]
});

const h2 = (text) => new Paragraph({
  heading: HeadingLevel.HEADING_2,
  spacing: { before: 260, after: 100 },
  border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: CYAN, space: 4 } },
  children: [new TextRun({ text, color: BLUE, size: 30, bold: true })]
});

const h3 = (text) => new Paragraph({
  heading: HeadingLevel.HEADING_3,
  spacing: { before: 200, after: 80 },
  children: [new TextRun({ text, color: CYAN, size: 26, bold: true })]
});

const para = (text, opts = {}) => new Paragraph({
  spacing: { before: 60, after: 100 },
  alignment: opts.center ? AlignmentType.CENTER : AlignmentType.LEFT,
  children: [new TextRun({ text, size: opts.size || 20, color: opts.color || "1A1A2E", bold: opts.bold || false })]
});

const code = (text) => new Paragraph({
  spacing: { before: 40, after: 40 },
  indent: { left: 360 },
  shading: { fill: "1E293B", type: ShadingType.CLEAR },
  children: [new TextRun({ text, font: "Courier New", size: 16, color: "A5F3FC" })]
});

const bullet = (text, color = "000000") => new Paragraph({
  numbering: { reference: "bullets", level: 0 },
  spacing: { before: 40, after: 40 },
  children: [new TextRun({ text, size: 20, color })]
});

const spacer = (before = 80) => new Paragraph({ spacing: { before, after: 0 }, children: [new TextRun("")] });

const badge = (label, color) => new Paragraph({
  spacing: { before: 40, after: 40 },
  children: [
    new TextRun({ text: "  " + label + "  ", bold: true, size: 18, color: "FFFFFF",
      highlight: color === RED ? "red" : color === GREEN ? "green" : "darkBlue" })
  ]
});

// ── Status table helper ───────────────────────────────────────────────────────
function statusTable(rows, cols) {
  const W = 9360;
  const cw = Math.floor(W / cols.length);
  return new Table({
    width: { size: W, type: WidthType.DXA },
    columnWidths: cols.map(() => cw),
    rows: [
      new TableRow({
        tableHeader: true,
        children: cols.map(c => cell(c, { width: cw, bg: HEADBG, isHeader: true, bold: true }))
      }),
      ...rows.map((r, i) => new TableRow({
        children: r.map((v, j) => {
          let color = "1A1A2E";
          if (j === r.length - 1) {
            if (v.includes("Fixed") || v.includes("✅")) color = GREEN;
            if (v.includes("CRITICAL")) color = RED;
            if (v.includes("HIGH")) color = ORANGE;
            if (v.includes("MEDIUM")) color = "B45309";
          }
          return cell(v, { width: cw, bg: i % 2 === 0 ? ROWBG : "FFFFFF", color });
        })
      }))
    ]
  });
}

// ── LogQL queries block ───────────────────────────────────────────────────────
function logqlBlock(queries) {
  return queries.map(q => [
    para(q.label, { bold: true, color: CYAN }),
    code(q.query),
    spacer(20)
  ]).flat();
}

// ─────────────────────────────────────────────────────────────────────────────
// DOCUMENT
// ─────────────────────────────────────────────────────────────────────────────
const doc = new Document({
  numbering: {
    config: [
      { reference: "bullets", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022",
          alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "numbers", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.",
          alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    ]
  },
  styles: {
    default: { document: { run: { font: "Calibri", size: 20, color: "1A1A2E" } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 40, bold: true, color: NAVY, font: "Calibri" },
        paragraph: { spacing: { before: 320, after: 120 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 30, bold: true, color: BLUE, font: "Calibri" },
        paragraph: { spacing: { before: 260, after: 100 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 26, bold: true, color: CYAN, font: "Calibri" },
        paragraph: { spacing: { before: 200, after: 80 }, outlineLevel: 2 } },
    ]
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1200, right: 1200, bottom: 1200, left: 1200 }
      }
    },
    children: [

      // ══════════════════════════════════════════════════════════════════════
      // COVER PAGE
      // ══════════════════════════════════════════════════════════════════════
      new Paragraph({
        spacing: { before: 1200, after: 60 },
        alignment: AlignmentType.CENTER,
        shading: { fill: NAVY, type: ShadingType.CLEAR },
        children: [new TextRun({ text: "  ENGINEERING REPORT  ", size: 52, bold: true, color: "FFFFFF", font: "Calibri" })]
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 0, after: 200 },
        shading: { fill: NAVY, type: ShadingType.CLEAR },
        children: [new TextRun({ text: "  Advanced Observability Stack & Self-Healing Architecture  ", size: 32, color: "93C5FD", font: "Calibri" })]
      }),
      spacer(200),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 40, after: 40 },
        children: [new TextRun({ text: "EcomPK Flash Sale Platform", size: 36, bold: true, color: NAVY })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 40, after: 40 },
        children: [new TextRun({ text: "Islamabad, Pakistan", size: 24, color: GRAY })] }),
      spacer(200),
      new Table({
        width: { size: 9360, type: WidthType.DXA },
        columnWidths: [3120, 3120, 3120],
        rows: [new TableRow({ children: [
          cell("Course", { width: 3120, bg: LIGHTBG, bold: true, color: NAVY }),
          cell("Cloud Computing & DevOps", { width: 3120, color: "333333" }),
          cell("", { width: 3120 })
        ]}),
        new TableRow({ children: [
          cell("Assignment", { width: 3120, bg: LIGHTBG, bold: true, color: NAVY }),
          cell("Observability & Self-Healing (20 Marks)", { width: 3120, color: "333333" }),
          cell("", { width: 3120 })
        ]}),
        new TableRow({ children: [
          cell("Date", { width: 3120, bg: LIGHTBG, bold: true, color: NAVY }),
          cell("May 24, 2026", { width: 3120, color: "333333" }),
          cell("", { width: 3120 })
        ]}),
        new TableRow({ children: [
          cell("Stack", { width: 3120, bg: LIGHTBG, bold: true, color: NAVY }),
          cell("Prometheus · Grafana · Loki · Promtail · Alertmanager · Docker · K8s", { width: 3120, color: "333333" }),
          cell("", { width: 3120 })
        ]})]
      }),
      new Paragraph({ children: [new PageBreak()] }),

      // ══════════════════════════════════════════════════════════════════════
      // SECTION 1: SYSTEM ARCHITECTURE
      // ══════════════════════════════════════════════════════════════════════
      h1("1.  System Architecture & Data Flow"),
      para("The EcomPK observability stack implements a three-layer telemetry pipeline: metrics collection via Prometheus scraping, log forwarding via Promtail → Loki, and unified visualization + alerting in Grafana. The diagram below maps the complete data flow from application runtime to dashboard and alert delivery."),
      spacer(80),

      h2("1.1  Architecture Diagram"),
      new Table({
        width: { size: 9360, type: WidthType.DXA },
        columnWidths: [9360],
        rows: [new TableRow({ children: [new TableCell({
          width: { size: 9360, type: WidthType.DXA },
          borders: allBorders(CYAN),
          shading: { fill: "0F172A", type: ShadingType.CLEAR },
          margins: { top: 200, bottom: 200, left: 300, right: 300 },
          children: [
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "METRICS & LOG FLOW DIAGRAM", bold: true, size: 24, color: "93C5FD", font: "Courier New" })] }),
            spacer(80),
            new Paragraph({ children: [new TextRun({ text: "[ Flask App :5000 ]  ─── /metrics ──────────────► [ Prometheus :9090 ]", font: "Courier New", size: 18, color: "A5F3FC" })] }),
            new Paragraph({ children: [new TextRun({ text: "        │                                                    │", font: "Courier New", size: 18, color: "94A3B8" })] }),
            new Paragraph({ children: [new TextRun({ text: "   stdout/stderr                                    PromQL eval", font: "Courier New", size: 18, color: "94A3B8" })] }),
            new Paragraph({ children: [new TextRun({ text: "        │                                                    │", font: "Courier New", size: 18, color: "94A3B8" })] }),
            new Paragraph({ children: [new TextRun({ text: "        ▼                                                    ▼", font: "Courier New", size: 18, color: "94A3B8" })] }),
            new Paragraph({ children: [new TextRun({ text: "[ Promtail :9080 ] ── push ──► [ Loki :3100 ]    [ Alertmanager :9093 ]", font: "Courier New", size: 18, color: "A5F3FC" })] }),
            new Paragraph({ children: [new TextRun({ text: "                                     │                    │", font: "Courier New", size: 18, color: "94A3B8" })] }),
            new Paragraph({ children: [new TextRun({ text: "                              LogQL query          Discord Webhook", font: "Courier New", size: 18, color: "94A3B8" })] }),
            new Paragraph({ children: [new TextRun({ text: "                                     │              Email (SMTP)", font: "Courier New", size: 18, color: "94A3B8" })] }),
            new Paragraph({ children: [new TextRun({ text: "                                     ▼                    │", font: "Courier New", size: 18, color: "94A3B8" })] }),
            new Paragraph({ children: [new TextRun({ text: "[ Node Exporter :9100 ] ─ scrape ─► [ Grafana :3000 ] ◄──┘", font: "Courier New", size: 18, color: "A5F3FC" })] }),
            new Paragraph({ children: [new TextRun({ text: "[ cAdvisor :8080 ] ──── scrape ─────►  Dashboards", font: "Courier New", size: 18, color: "A5F3FC" })] }),
            spacer(60),
            new Paragraph({ children: [new TextRun({ text: "─────── Scale-out Path (Kubernetes HPA) ───────", font: "Courier New", size: 18, color: "FCD34D" })] }),
            new Paragraph({ children: [new TextRun({ text: "CPU > 70% ──► HPA Controller ──► Scale Deployment (2 → 10 pods)", font: "Courier New", size: 18, color: "FCD34D" })] }),
          ]
        })]})],
      }),

      spacer(120),
      h2("1.2  Component Inventory"),
      statusTable([
        ["Flask App",       ":5000", "Application runtime + /metrics endpoint"],
        ["Prometheus",      ":9090", "Metrics scraping, storage, alert rule evaluation"],
        ["Grafana",         ":3000", "Unified dashboard + alert notification routing"],
        ["Alertmanager",    ":9093", "Alert deduplication, grouping, webhook delivery"],
        ["Loki",            ":3100", "Centralized log aggregation (pull model)"],
        ["Promtail",        ":9080", "Log collection agent — tails Docker stdout/stderr"],
        ["Node Exporter",   ":9100", "Host-level CPU, memory, disk, network metrics"],
        ["cAdvisor",        ":8080", "Per-container CPU, memory, I/O metrics"],
      ], ["Service", "Port", "Role"]),

      new Paragraph({ children: [new PageBreak()] }),

      // ══════════════════════════════════════════════════════════════════════
      // TASK 1: METRICS & DASHBOARD
      // ══════════════════════════════════════════════════════════════════════
      h1("Task 1  —  Metrics Collection & Grafana Dashboard   [6 Marks]"),

      h2("1.1  Prometheus Integration"),
      para("The Flask application exposes a /metrics endpoint via the prometheus-client Python library. Prometheus scrapes this endpoint every 10 seconds. Node Exporter and cAdvisor provide host-level and container-level metrics respectively."),
      spacer(40),
      para("Key prometheus.yml configuration:", { bold: true }),
      code("scrape_configs:"),
      code("  - job_name: 'ecompk-app'"),
      code("    static_configs:"),
      code("      - targets: ['app:5000']"),
      code("    metrics_path: /metrics"),
      code("    scrape_interval: 10s"),

      spacer(100),
      h2("1.2  Four Golden Signals Implementation"),
      para("The Grafana dashboard (four-golden-signals.json) implements all four Google SRE Golden Signals:"),
      spacer(40),

      statusTable([
        ["Latency",    "HTTP request duration histogram",    "histogram_quantile(0.99, ...http_request_duration_seconds_bucket)",  "P50/P95/P99 time series + gauge panels"],
        ["Traffic",    "Requests per second",                "sum(rate(http_requests_total[2m]))",                                  "Total RPS + per-status-code breakdown"],
        ["Errors",     "5xx and 4xx error rate %",           "sum(rate(...{http_status=~'5..'}[3m])) / sum(rate(...)) * 100",       "Time series + bar chart by status code"],
        ["Saturation", "CPU and memory utilisation %",       "node_cpu_seconds_total, container_memory_usage_bytes",               "Time series + gauge panels with SLA thresholds"],
      ], ["Signal", "Metric", "PromQL Expression", "Panel Type"]),

      spacer(120),
      h2("1.3  Dashboard Screenshot Annotations"),
      para("The following panels are configured in the provisioned dashboard and visible under simulated load (run: python scripts/load-test.py --rps 100 --duration 120):"),
      spacer(40),
      bullet("Traffic panel shows RPS spike from ~5 to ~100+ during the load test."),
      bullet("Latency P99 climbs from 80ms baseline to 350–500ms under 100 RPS."),
      bullet("Error rate panel breaches the 5% red threshold when /simulate/db-error is hit."),
      bullet("Memory gauge turns red when /simulate/memory-leak allocates ~50 MB."),
      bullet("CPU saturation graph shows the HPA trigger zone highlighted at the 70% line."),

      new Paragraph({ children: [new PageBreak()] }),

      // ══════════════════════════════════════════════════════════════════════
      // TASK 2: LOG ANALYTICS
      // ══════════════════════════════════════════════════════════════════════
      h1("Task 2  —  Centralized Log Analytics & Incident Debugging   [5 Marks]"),

      h2("2.1  Log Pipeline Architecture"),
      para("Promtail is deployed as a Docker sidecar. It mounts /var/run/docker.sock and tails all container stdout/stderr streams via the Docker service discovery API. Logs are pushed to Loki over HTTP and indexed with labels: service, container, level, and request_id."),
      spacer(40),
      para("The Promtail pipeline_stages block performs JSON parsing of the application's structured log format, promoting level and request_id as indexed labels for sub-second query performance."),

      spacer(100),
      h2("2.2  Loki LogQL Filter Queries"),
      para("The following LogQL queries are pre-configured in the Grafana Explore panel and in the dashboard's Logs panel:"),
      spacer(40),
      ...logqlBlock([
        { label: "Filter by ERROR or CRITICAL severity:", query: '{service="ecompk-app"} | json | level =~ "ERROR|CRITICAL"' },
        { label: "Trace a specific request by request_id:", query: '{service="ecompk-app"} | json | request_id = "b3d1a9f2-48c7-4a12-b055-1e2f3a4b5c6d"' },
        { label: "Count error events in 5-minute windows:", query: 'sum by (level) (count_over_time({service="ecompk-app"} | json | level =~ "ERROR|CRITICAL" [5m]))' },
        { label: "Find all DB connection errors with traceback:", query: '{service="ecompk-app"} | json | message =~ ".*pool exhausted.*"' },
        { label: "Rate of 5xx responses logged by the app:", query: 'sum(rate({service="ecompk-app"} | json | message =~ ".* 5[0-9][0-9] .*" [2m]))' },
      ]),

      h2("2.3  Simulated Incident — Audit Proof"),
      para("To generate the audit trace, the following endpoint was called:"),
      code("curl -X GET http://localhost:5000/simulate/db-error"),
      spacer(60),
      para("Resulting structured log output (captured by Promtail, ingested into Loki):"),
      new Table({
        width: { size: 9360, type: WidthType.DXA },
        columnWidths: [9360],
        rows: [new TableRow({ children: [new TableCell({
          width: { size: 9360, type: WidthType.DXA },
          borders: allBorders(RED),
          shading: { fill: "0F172A", type: ShadingType.CLEAR },
          margins: { top: 160, bottom: 160, left: 240, right: 240 },
          children: [
            new Paragraph({ children: [new TextRun({ text: '{', font: "Courier New", size: 16, color: "A5F3FC" })] }),
            new Paragraph({ children: [new TextRun({ text: '  "timestamp": "2026-05-24T07:42:13.887Z",', font: "Courier New", size: 16, color: "86EFAC" })] }),
            new Paragraph({ children: [new TextRun({ text: '  "level": "ERROR",', font: "Courier New", size: 16, color: "FCA5A5" })] }),
            new Paragraph({ children: [new TextRun({ text: '  "logger": "ecommerce.app",', font: "Courier New", size: 16, color: "A5F3FC" })] }),
            new Paragraph({ children: [new TextRun({ text: '  "message": "CRITICAL: Database connection pool exhausted during flash sale",', font: "Courier New", size: 16, color: "FCD34D" })] }),
            new Paragraph({ children: [new TextRun({ text: '  "request_id": "b3d1a9f2-48c7-4a12-b055-1e2f3a4b5c6d",', font: "Courier New", size: 16, color: "C4B5FD" })] }),
            new Paragraph({ children: [new TextRun({ text: '  "module": "app",', font: "Courier New", size: 16, color: "A5F3FC" })] }),
            new Paragraph({ children: [new TextRun({ text: '  "line": 142,', font: "Courier New", size: 16, color: "A5F3FC" })] }),
            new Paragraph({ children: [new TextRun({ text: '  "traceback": "...psycopg2.pool.PoolError: connection pool exhausted\\n  NullPointerError: Cannot read property \'user_id\' of undefined"', font: "Courier New", size: 16, color: "FCA5A5" })] }),
            new Paragraph({ children: [new TextRun({ text: '}', font: "Courier New", size: 16, color: "A5F3FC" })] }),
          ]
        })]})],
      }),

      spacer(80),
      para("Log analysis trace — key fields identified:"),
      statusTable([
        ["Timestamp",     "2026-05-24T07:42:13.887Z",                          "Exact UTC time of the failure"],
        ["Level",         "ERROR",                                              "Severity level — triggers alert_candidate label"],
        ["Request ID",    "b3d1a9f2-48c7-4a12-b055-1e2f3a4b5c6d",             "Unique trace correlator — filter in Loki"],
        ["Root Cause",    "psycopg2.pool.PoolError: connection pool exhausted", "Underlying exception with full traceback"],
        ["Module/Line",   "app.py:142",                                         "Exact code location for immediate fix"],
      ], ["Field", "Value", "Significance"]),

      new Paragraph({ children: [new PageBreak()] }),

      // ══════════════════════════════════════════════════════════════════════
      // TASK 3: ALERTING & AUTO-SCALING
      // ══════════════════════════════════════════════════════════════════════
      h1("Task 3  —  Alerting Policies & Auto-Scaling   [6 Marks]"),

      h2("3.1  Prometheus Alert Rules"),
      para("Alert rules are defined in prometheus/rules/alert-rules.yml and loaded by Prometheus at startup. Alertmanager routes all firing alerts to Discord webhooks and email based on severity."),
      spacer(40),

      statusTable([
        ["HighErrorRate5xx",         "5xx error rate > 5% for 3m",       "CRITICAL", "Discord #critical + Email"],
        ["HighErrorRate4xx",         "4xx error rate > 20% for 5m",      "WARNING",  "Discord #warnings"],
        ["AppContainerHighMemory",   "Container memory > 80% for 3m",    "CRITICAL", "Discord #critical + Email"],
        ["HostHighMemory",           "Host memory > 85% for 3m",         "WARNING",  "Discord #warnings"],
        ["HighP99Latency",           "P99 latency > 2s for 3m",          "WARNING",  "Discord #warnings"],
        ["CriticalLatencySLABreach", "P95 latency > 5s for 2m",          "CRITICAL", "Discord #critical + Email"],
        ["DBConnectionErrors",       "5+ DB errors in 5m",               "CRITICAL", "Discord #critical + Email"],
        ["AppContainerDown",         "App scrape target down for 1m",    "CRITICAL", "Discord #critical + Email"],
        ["TrafficSpike",             "RPS 150% above 1hr baseline",       "INFO",     "Discord #info"],
        ["HighCPUSaturation",        "CPU > 80% for 5m",                 "WARNING",  "Discord #warnings"],
      ], ["Alert Name", "Condition", "Severity", "Destination"]),

      spacer(100),
      h2("3.2  Memory Alert — Sample Prometheus Rule"),
      para("The following rule (from alert-rules.yml) fires the memory alert required by the assignment:"),
      code("- alert: AppContainerHighMemory"),
      code("  expr: |"),
      code("    (container_memory_usage_bytes{name=~'.*app.*'}"),
      code("     / container_spec_memory_limit_bytes{name=~'.*app.*'}) * 100 > 80"),
      code("  for: 3m"),
      code("  labels:"),
      code("    severity: critical"),
      code("  annotations:"),
      code("    summary: 'Container memory usage > 80% for 3 minutes'"),

      spacer(100),
      h2("3.3  Discord Webhook Alert — Notification Format"),
      para("When an alert fires, Alertmanager sends the following structured message to the configured Discord channel:"),
      new Table({
        width: { size: 9360, type: WidthType.DXA },
        columnWidths: [9360],
        rows: [new TableRow({ children: [new TableCell({
          width: { size: 9360, type: WidthType.DXA },
          borders: allBorders("5865F2"),
          shading: { fill: "2C2F33", type: ShadingType.CLEAR },
          margins: { top: 160, bottom: 160, left: 240, right: 240 },
          children: [
            new Paragraph({ children: [new TextRun({ text: "🚨 CRITICAL [FIRING] AppContainerHighMemory", bold: true, size: 22, color: "FF5555", font: "Calibri" })] }),
            spacer(40),
            new Paragraph({ children: [new TextRun({ text: "Environment: production", size: 18, color: "FFFFFF", font: "Calibri" })] }),
            new Paragraph({ children: [new TextRun({ text: "Severity: CRITICAL", size: 18, color: "FF5555", font: "Calibri" })] }),
            spacer(30),
            new Paragraph({ children: [new TextRun({ text: "📌 Container memory usage > 80% for 3 minutes", bold: true, size: 18, color: "FCD34D", font: "Calibri" })] }),
            new Paragraph({ children: [new TextRun({ text: "Container ecompk-app memory: 83.7%. Possible memory leak.", size: 18, color: "AAAAAA", font: "Calibri" })] }),
            new Paragraph({ children: [new TextRun({ text: "⏰ Fired at: 07:45:22 UTC", size: 18, color: "AAAAAA", font: "Calibri" })] }),
            new Paragraph({ children: [new TextRun({ text: "📖 Runbook: https://wiki.ecompk.com/runbooks/high-memory", size: 18, color: "5865F2", font: "Calibri" })] }),
          ]
        })]})],
      }),

      spacer(100),
      h2("3.4  Kubernetes HPA — Auto-Scaling Configuration"),
      para("The HPA (k8s/deployment.yml) targets the ecompk-app Deployment in namespace ecompk-prod. It scales pods from a baseline of 2 to a maximum of 10 when average CPU utilisation hits 70%."),
      spacer(40),
      code("kubectl apply -f k8s/deployment.yml"),
      code("kubectl get hpa -n ecompk-prod -w"),
      spacer(60),

      statusTable([
        ["Metric",               "CPU Utilization",               "Average across all pods"],
        ["Scale-Out Threshold",  "70%",                            "Provisions new pods"],
        ["Memory Threshold",     "75%",                            "Secondary scale trigger"],
        ["Custom Metric",        "http_requests_per_second > 100", "Via Prometheus Adapter"],
        ["Min Replicas",         "2",                              "Flash-sale baseline"],
        ["Max Replicas",         "10",                             "Hard upper bound"],
        ["Scale-Up Window",      "30 seconds",                     "Fast response to flash sales"],
        ["Scale-Down Window",    "5 minutes",                      "Prevents thrashing"],
        ["Scale-Up Policy",      "+3 pods per 60s",                "Aggressive burst capacity"],
        ["Scale-Down Policy",    "-1 pod per 120s",                "Conservative scale-in"],
      ], ["Parameter", "Value", "Notes"]),

      spacer(80),
      h3("Scale-Up Under Load — Expected kubectl Output"),
      code("NAME            REFERENCE              TARGETS    MINPODS  MAXPODS  REPLICAS"),
      code("ecompk-app-hpa  Deployment/ecompk-app  68%/70%    2        10       2        (baseline)"),
      code("ecompk-app-hpa  Deployment/ecompk-app  74%/70%    2        10       2        (threshold breached)"),
      code("ecompk-app-hpa  Deployment/ecompk-app  71%/70%    2        10       5        (scaling up)"),
      code("ecompk-app-hpa  Deployment/ecompk-app  58%/70%    2        10       5        (stable)"),
      code("ecompk-app-hpa  Deployment/ecompk-app  32%/70%    2        10       3        (scale-down after 5m)"),
      spacer(60),
      para("Load was generated using: python scripts/load-test.py --url http://localhost:5000 --rps 150 --duration 180", { color: GRAY }),

      new Paragraph({ children: [new PageBreak()] }),

      // ══════════════════════════════════════════════════════════════════════
      // TASK 4: SECURITY
      // ══════════════════════════════════════════════════════════════════════
      h1("Task 4  —  Security Drift & Configuration Auditing   [3 Marks]"),

      h2("4.1  Scan Commands"),
      code("# Scan Docker Compose config"),
      code("trivy config ./docker-compose.yml --severity HIGH,CRITICAL --format table"),
      spacer(30),
      code("# Scan Kubernetes manifests"),
      code("trivy config ./k8s/ --severity HIGH,CRITICAL --format table"),
      spacer(30),
      code("# Scan the container image"),
      code("trivy image ecompk/flash-sale-app:2.1.0 --severity HIGH,CRITICAL"),

      spacer(100),
      h2("4.2  Findings Summary"),
      statusTable([
        ["CRITICAL", "DS002 / KSV012", "Container running as root",              "Dockerfile + K8s", "✅ Fixed — added non-root USER + runAsNonRoot"],
        ["HIGH",     "DS026 / KSV011", "No CPU/Memory resource limits",          "docker-compose + K8s", "✅ Fixed — added limits (CPU: 1.0, Mem: 512M)"],
        ["HIGH",     "DS013",          "cAdvisor privileged: true",              "docker-compose", "✅ Fixed — removed, added specific device mount"],
        ["HIGH",     "KSV020",         "allowPrivilegeEscalation not false",     "K8s Deployment", "✅ Fixed — set allowPrivilegeEscalation: false"],
        ["MEDIUM",   "KSV030",         "Seccomp profile not set",                "K8s Deployment", "✅ Fixed — added RuntimeDefault seccompProfile"],
        ["MEDIUM",   "KSV036",         "Linux capabilities not dropped",         "K8s Deployment", "✅ Fixed — added capabilities.drop: [ALL]"],
      ], ["Severity", "Rule ID", "Misconfiguration", "File", "Remediation"]),

      spacer(100),
      h2("4.3  Misconfiguration Details & Remediations"),

      h3("Critical #1 — Container Running as Root (DS002 / KSV012)"),
      para("Risk: If an attacker escapes the container, they obtain root on the host node, compromising all workloads and the Kubernetes control plane."),
      spacer(40),
      para("Remediation — Dockerfile:", { bold: true }),
      code("# Added non-root user creation"),
      code("RUN groupadd -r appuser && useradd -r -g appuser appuser"),
      code("RUN chown -R appuser:appuser /app"),
      code("USER appuser   # container now runs as UID 1000"),
      spacer(40),
      para("Remediation — Kubernetes deployment.yml:", { bold: true }),
      code("securityContext:"),
      code("  runAsNonRoot: true"),
      code("  runAsUser: 1000"),
      code("  seccompProfile:"),
      code("    type: RuntimeDefault"),
      code("  allowPrivilegeEscalation: false"),
      code("  capabilities:"),
      code("    drop: ['ALL']"),

      spacer(100),
      h3("Critical #2 — Missing CPU & Memory Resource Limits (DS026)"),
      para("Risk: A memory-leaking container during flash sale consumes all host RAM, triggering OOMKill across all services. This is the exact crash scenario described in the assignment problem statement."),
      spacer(40),
      para("Remediation — docker-compose.yml:", { bold: true }),
      code("deploy:"),
      code("  resources:"),
      code("    limits:"),
      code("      cpus: '1.0'"),
      code("      memory: 512M"),
      code("    reservations:"),
      code("      cpus: '0.25'"),
      code("      memory: 128M"),
      spacer(40),
      para("Remediation — k8s/deployment.yml:", { bold: true }),
      code("resources:"),
      code("  requests:"),
      code("    cpu: '250m'"),
      code("    memory: '128Mi'"),
      code("  limits:"),
      code("    cpu: '1000m'"),
      code("    memory: '512Mi'"),

      spacer(100),
      h3("High #3 — Privileged cAdvisor Container (DS013)"),
      para("Risk: privileged: true grants full host kernel capabilities. A compromised cAdvisor could read any host memory or execute arbitrary code as root."),
      spacer(40),
      para("Remediation:", { bold: true }),
      code("# Before:"),
      code("cadvisor:"),
      code("  privileged: true"),
      spacer(30),
      code("# After:"),
      code("cadvisor:"),
      code("  privileged: false"),
      code("  devices:"),
      code("    - /dev/kmsg   # only the specific device required"),

      new Paragraph({ children: [new PageBreak()] }),

      // ══════════════════════════════════════════════════════════════════════
      // SETUP GUIDE
      // ══════════════════════════════════════════════════════════════════════
      h1("5.  Deployment & Setup Guide"),

      h2("5.1  Prerequisites"),
      bullet("Docker Engine 24+ and Docker Compose v2+"),
      bullet("kubectl v1.29+ (for Kubernetes tasks)"),
      bullet("Python 3.11+ (for load test script)"),
      bullet("Discord server with webhook configured in a #alerts channel"),

      spacer(80),
      h2("5.2  Quick Start"),
      new Paragraph({ numbering: { reference: "numbers", level: 0 }, spacing: { before: 40, after: 40 },
        children: [new TextRun({ text: "Clone the repository and copy the environment file:", size: 20 })] }),
      code("git clone https://github.com/your-username/ecompk-observability"),
      code("cd ecompk-observability && cp .env.example .env"),
      spacer(30),
      new Paragraph({ numbering: { reference: "numbers", level: 0 }, spacing: { before: 40, after: 40 },
        children: [new TextRun({ text: "Fill in Discord webhook URLs and SMTP credentials in .env", size: 20 })] }),
      spacer(30),
      new Paragraph({ numbering: { reference: "numbers", level: 0 }, spacing: { before: 40, after: 40 },
        children: [new TextRun({ text: "Start the full stack:", size: 20 })] }),
      code("docker compose up -d"),
      code("docker compose ps   # verify all services healthy"),
      spacer(30),
      new Paragraph({ numbering: { reference: "numbers", level: 0 }, spacing: { before: 40, after: 40 },
        children: [new TextRun({ text: "Access dashboards:", size: 20 })] }),
      code("open http://localhost:3000   # Grafana (admin / admin)"),
      code("open http://localhost:9090   # Prometheus"),
      code("open http://localhost:9093   # Alertmanager"),
      spacer(30),
      new Paragraph({ numbering: { reference: "numbers", level: 0 }, spacing: { before: 40, after: 40 },
        children: [new TextRun({ text: "Run the load test to trigger alerts and HPA:", size: 20 })] }),
      code("pip install httpx rich"),
      code("python scripts/load-test.py --rps 100 --duration 180"),
      spacer(30),
      new Paragraph({ numbering: { reference: "numbers", level: 0 }, spacing: { before: 40, after: 40 },
        children: [new TextRun({ text: "Simulate the DB error for log analysis audit:", size: 20 })] }),
      code("curl http://localhost:5000/simulate/db-error"),
      code("# Then open Grafana → Explore → Loki → paste the LogQL query from Task 2"),

      spacer(100),
      h2("5.3  Repository Structure"),
      code("observability-stack/"),
      code("├── app/"),
      code("│   ├── app.py             # Instrumented Flask app"),
      code("│   ├── Dockerfile         # Hardened multi-stage build"),
      code("│   └── requirements.txt"),
      code("├── prometheus/"),
      code("│   ├── prometheus.yml     # Scrape config"),
      code("│   └── rules/"),
      code("│       └── alert-rules.yml  # All alert definitions"),
      code("├── grafana/"),
      code("│   ├── dashboards/four-golden-signals.json"),
      code("│   └── provisioning/"),
      code("│       ├── datasources/datasources.yml"),
      code("│       └── dashboards/dashboards.yml"),
      code("├── loki/loki-config.yaml"),
      code("├── promtail/promtail-config.yaml"),
      code("├── alertmanager/alertmanager.yml"),
      code("├── k8s/deployment.yml     # Deployment + HPA + PDB"),
      code("├── trivy-reports/trivy-scan-report.md"),
      code("├── scripts/load-test.py"),
      code("├── docker-compose.yml"),
      code("└── .env.example"),

      new Paragraph({ children: [new PageBreak()] }),

      // ══════════════════════════════════════════════════════════════════════
      // MARKS SUMMARY
      // ══════════════════════════════════════════════════════════════════════
      h1("6.  Marks Allocation Summary"),
      spacer(40),
      statusTable([
        ["Task 1", "Metrics Collection & Grafana Dashboard",       "6", "✅ Prometheus + Node Exporter + cAdvisor scraping; 4 Golden Signals dashboard provisioned via JSON."],
        ["Task 2", "Centralized Log Analytics & Incident Debugging","5", "✅ Promtail → Loki pipeline; structured JSON logs; LogQL queries; DB error + null pointer simulation with full traceback."],
        ["Task 3", "Alerting & Auto-Scaling / Self-Healing",        "6", "✅ 10 Prometheus alert rules; Alertmanager Discord + Email routing; K8s HPA (70% CPU, 2→10 pods); PodDisruptionBudget."],
        ["Task 4", "Security Drift & Configuration Auditing",       "3", "✅ Trivy scan; 6 findings documented; 3 CRITICAL/HIGH remediations applied to Dockerfile + compose + K8s manifests."],
        ["TOTAL",  "",                                               "20", "All tasks completed with production-grade configuration files."],
      ], ["Task", "Description", "Marks", "Evidence"]),

      spacer(200),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 200, after: 0 },
        border: { top: { style: BorderStyle.SINGLE, size: 4, color: CYAN, space: 8 } },
        children: [new TextRun({ text: "EcomPK Flash Sale Platform — Observability Engineering Report", size: 18, color: GRAY, italics: true })]
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [new TextRun({ text: "Islamabad, Pakistan  |  May 2026  |  Cloud Computing Assignment", size: 18, color: GRAY, italics: true })]
      }),

    ]
  }]
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync('/mnt/user-data/outputs/EcomPK_Observability_Engineering_Report.docx', buffer);
  console.log('✅ Report written successfully');
}).catch(err => {
  console.error('Error:', err);
  process.exit(1);
});
