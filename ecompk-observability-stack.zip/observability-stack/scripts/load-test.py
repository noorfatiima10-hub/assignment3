#!/usr/bin/env python3
"""
load-test.py — Flash Sale Pressure Simulator
Simulates a Pakistani e-commerce flash sale with concurrent users.

Usage:
    pip install httpx rich
    python load-test.py --url http://localhost:5000 --rps 100 --duration 120
"""

import asyncio
import argparse
import time
import random
from datetime import datetime

import httpx
from rich.console import Console
from rich.table import Table
from rich.live import Live
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn

console = Console()

ENDPOINTS = [
    ("/products",         "GET",  None, 0.50),
    ("/orders",           "POST", {"product_id": "PKT-001", "qty": 1}, 0.30),
    ("/health",           "GET",  None, 0.10),
    ("/simulate/db-error","GET",  None, 0.05),   # inject errors for alerting demo
    ("/simulate/null-pointer", "GET", None, 0.05),
]


class Stats:
    def __init__(self):
        self.total = 0
        self.success = 0
        self.errors_5xx = 0
        self.errors_4xx = 0
        self.latencies = []
        self.start = time.time()

    def record(self, status: int, latency: float):
        self.total += 1
        self.latencies.append(latency)
        if 200 <= status < 400:
            self.success += 1
        elif 400 <= status < 500:
            self.errors_4xx += 1
        elif status >= 500:
            self.errors_5xx += 1

    @property
    def rps(self):
        elapsed = time.time() - self.start
        return self.total / elapsed if elapsed > 0 else 0

    @property
    def p99(self):
        if not self.latencies:
            return 0
        s = sorted(self.latencies)
        return s[int(len(s) * 0.99)]

    @property
    def error_rate(self):
        if self.total == 0:
            return 0
        return (self.errors_5xx + self.errors_4xx) / self.total * 100


async def single_request(client: httpx.AsyncClient, base_url: str, stats: Stats):
    path, method, body, _ = random.choices(
        ENDPOINTS, weights=[e[3] for e in ENDPOINTS]
    )[0]
    url = base_url + path
    t0 = time.perf_counter()
    try:
        if method == "GET":
            r = await client.get(url, timeout=10)
        else:
            r = await client.post(url, json=body, timeout=10)
        stats.record(r.status_code, time.perf_counter() - t0)
    except Exception:
        stats.record(503, time.perf_counter() - t0)


async def run_load(base_url: str, rps: int, duration: int):
    stats = Stats()
    interval = 1.0 / rps
    deadline = time.time() + duration
    semaphore = asyncio.Semaphore(rps * 2)   # cap concurrency

    console.print(f"\n[bold cyan]🚀 EcomPK Flash Sale Load Test[/bold cyan]")
    console.print(f"   Target: [yellow]{base_url}[/yellow]")
    console.print(f"   RPS: {rps}  |  Duration: {duration}s\n")

    async with httpx.AsyncClient() as client:
        async def worker():
            async with semaphore:
                await single_request(client, base_url, stats)

        table = Table(title="Live Stats", show_header=True)
        table.add_column("Metric",      style="cyan")
        table.add_column("Value",       style="green")

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("{task.completed}/{task.total}s"),
        ) as progress:
            task = progress.add_task("Running load test...", total=duration)

            while time.time() < deadline:
                asyncio.create_task(worker())
                await asyncio.sleep(interval)
                elapsed = int(time.time() - stats.start)
                progress.update(task, completed=min(elapsed, duration))

    # ── Final Report ─────────────────────────────────────────────────────────
    console.print("\n[bold green]✅ Load Test Complete[/bold green]\n")
    t = Table(title="Final Results", show_header=True, header_style="bold magenta")
    t.add_column("Metric")
    t.add_column("Value", justify="right")
    t.add_row("Total Requests",   str(stats.total))
    t.add_row("Avg RPS",          f"{stats.rps:.1f}")
    t.add_row("Success (2xx/3xx)",f"{stats.success}")
    t.add_row("4xx Errors",       f"[yellow]{stats.errors_4xx}[/yellow]")
    t.add_row("5xx Errors",       f"[red]{stats.errors_5xx}[/red]")
    t.add_row("Error Rate",       f"[{'red' if stats.error_rate > 5 else 'green'}]{stats.error_rate:.2f}%[/]")
    t.add_row("P99 Latency",      f"{stats.p99*1000:.1f} ms")
    console.print(t)

    if stats.error_rate > 5:
        console.print("\n[bold red]⚠️  Error rate > 5% — Alertmanager alert should have fired![/bold red]")
    else:
        console.print("\n[green]✓ Error rate within SLA[/green]")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="EcomPK Flash Sale Load Tester")
    parser.add_argument("--url",      default="http://localhost:5000")
    parser.add_argument("--rps",      type=int, default=50)
    parser.add_argument("--duration", type=int, default=120)
    args = parser.parse_args()
    asyncio.run(run_load(args.url, args.rps, args.duration))
