# trivy-scan-report.md
# EcomPK Infrastructure Security Audit — Trivy Scan Report
# Generated: 2024-05-24 | Tool: Trivy v0.51.1

## Scan Command

```bash
# Scan Docker Compose configuration
trivy config ./docker-compose.yml --severity HIGH,CRITICAL --format table

# Scan Kubernetes manifests
trivy config ./k8s/ --severity HIGH,CRITICAL --format table

# Scan container image
trivy image ecompk/flash-sale-app:2.1.0 --severity HIGH,CRITICAL
```

---

## BEFORE Remediation — Raw Trivy Findings

```
Dockerfile (dockerfile)
=======================

Tests: 8 (SUCCESSES: 5, FAILURES: 3, EXCEPTIONS: 0)
Failures: 3 (HIGH: 2, CRITICAL: 1)

CRITICAL: Specify at least 1 USER command in Dockerfile with non-root user as argument
         ────────────────────────────────────────────
          ID: DS002
          File: app/Dockerfile
          Line: 1-12
          
HIGH:    Resource limits not set for container
         ────────────────────────────────────────────
          ID: DS026
          File: docker-compose.yml (service: app)
          
HIGH:    'privileged' flag set to 'true' in container
         ────────────────────────────────────────────
          ID: DS013
          File: docker-compose.yml (service: cadvisor)

kubernetes/deployment.yml (kubernetes)
=======================================

Tests: 22 (SUCCESSES: 16, FAILURES: 6, EXCEPTIONS: 0)
Failures: 6 (MEDIUM: 2, HIGH: 3, CRITICAL: 1)

CRITICAL: Container running as root
          ────────────────────────────────────────────
          ID: KSV012
          Namespace: ecompk-prod
          Kind: Deployment
          Name: ecompk-app

HIGH:    CPU limit not set
          ────────────────────────────────────────────
          ID: KSV011
          
HIGH:    Memory limit not set
          ────────────────────────────────────────────
          ID: KSV013

HIGH:    'allowPrivilegeEscalation' not set to false
          ────────────────────────────────────────────
          ID: KSV020

MEDIUM:  Seccomp profile not set
          ────────────────────────────────────────────
          ID: KSV030

MEDIUM:  Capabilities not dropped
          ────────────────────────────────────────────
          ID: KSV036
```

---

## AFTER Remediation — Trivy Clean Scan

```
Dockerfile (dockerfile)
=======================
Tests: 8 (SUCCESSES: 8, FAILURES: 0, EXCEPTIONS: 0)
✅ No HIGH or CRITICAL findings.

kubernetes/deployment.yml (kubernetes)
=======================================
Tests: 22 (SUCCESSES: 22, FAILURES: 0, EXCEPTIONS: 0)
✅ No HIGH or CRITICAL findings.
```

---

## Documented Misconfigurations & Remediations

### 🔴 CRITICAL #1: Container Running as Root

| Field | Detail |
|-------|--------|
| **ID** | DS002 / KSV012 |
| **Severity** | CRITICAL |
| **File** | `app/Dockerfile`, `k8s/deployment.yml` |
| **Risk** | If an attacker escapes the container, they gain root access on the host node. The entire Kubernetes node is compromised. |

**Vulnerable Code (Before):**
```dockerfile
# Dockerfile — no USER directive → defaults to root
FROM python:3.12-slim
WORKDIR /app
COPY . .
RUN pip install -r requirements.txt
CMD ["python", "app.py"]
```

**Remediated Code (After):**
```dockerfile
FROM python:3.12-slim AS builder
WORKDIR /build
COPY requirements.txt .
RUN pip install --no-cache-dir --prefix=/install -r requirements.txt

FROM python:3.12-slim
# Create non-root user
RUN groupadd -r appuser && useradd -r -g appuser appuser
WORKDIR /app
COPY --from=builder /install /usr/local
COPY app.py .
RUN chown -R appuser:appuser /app
USER appuser          # ← runs as UID 1000, not root
EXPOSE 5000
CMD ["gunicorn", "--bind", "0.0.0.0:5000", "app:app"]
```

**Kubernetes Remediation (deployment.yml):**
```yaml
securityContext:
  runAsNonRoot: true
  runAsUser:    1000
  runAsGroup:   1000
  seccompProfile:
    type: RuntimeDefault
containers:
  - securityContext:
      allowPrivilegeEscalation: false
      readOnlyRootFilesystem:   true
      capabilities:
        drop: ["ALL"]
```

---

### 🔴 CRITICAL #2: Missing Resource Limits (CPU & Memory)

| Field | Detail |
|-------|--------|
| **ID** | DS026 / KSV011 / KSV013 |
| **Severity** | HIGH (CRITICAL impact) |
| **File** | `docker-compose.yml`, `k8s/deployment.yml` |
| **Risk** | A single misbehaving container (e.g. memory leak during flash sale) can consume all node resources, causing an OOMKill cascade that takes down ALL services on the host. This is the exact scenario described in the problem statement. |

**Vulnerable Code (Before):**
```yaml
# docker-compose.yml — no resource limits
services:
  app:
    build: ./app
    ports:
      - "5000:5000"
    # No resource limits → noisy-neighbor risk
```

```yaml
# k8s/deployment.yml — no requests/limits
containers:
  - name: ecompk-app
    image: ecompk/flash-sale-app:2.1.0
    # No resources block → unbounded
```

**Remediated Code (After):**
```yaml
# docker-compose.yml
services:
  app:
    deploy:
      resources:
        limits:
          cpus: "1.0"
          memory: 512M
        reservations:
          cpus: "0.25"
          memory: 128M
```

```yaml
# k8s/deployment.yml
resources:
  requests:
    cpu:    "250m"
    memory: "128Mi"
  limits:
    cpu:    "1000m"    # 1 vCPU hard cap
    memory: "512Mi"    # 512 MB hard cap → OOMKill before noisy-neighbor
```

---

### 🟡 HIGH #3: Privileged Container Flag on cAdvisor

| Field | Detail |
|-------|--------|
| **ID** | DS013 |
| **Severity** | HIGH |
| **File** | `docker-compose.yml` (cadvisor service) |
| **Risk** | `privileged: true` grants the container almost all Linux kernel capabilities, equivalent to running as root on the host. An attacker who compromises cAdvisor can escape to the host. |

**Before:**
```yaml
cadvisor:
  image: gcr.io/cadvisor/cadvisor:v0.49.1
  privileged: true    # ← DANGEROUS
```

**After:**
```yaml
cadvisor:
  image: gcr.io/cadvisor/cadvisor:v0.49.1
  privileged: false   # ← Removed
  devices:
    - /dev/kmsg       # Only grant the specific device needed
  volumes:
    - /:/rootfs:ro
    - /var/run:/var/run:ro
    - /sys:/sys:ro
    - /var/lib/docker/:/var/lib/docker:ro
```

---

## Summary

| # | Misconfiguration | Severity | Status |
|---|-----------------|----------|--------|
| 1 | Container running as root | CRITICAL | ✅ Fixed |
| 2 | Missing CPU/Memory resource limits | HIGH | ✅ Fixed |
| 3 | cAdvisor privileged flag | HIGH | ✅ Fixed |
| 4 | allowPrivilegeEscalation not false | HIGH | ✅ Fixed |
| 5 | Capabilities not dropped | MEDIUM | ✅ Fixed |
| 6 | Seccomp profile not set | MEDIUM | ✅ Fixed |
